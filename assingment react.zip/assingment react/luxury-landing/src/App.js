import { useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import useResponsive from './utils/useResponsive';
import Header from './components/Header';
import Hero from './components/Hero';
import Products from './components/Products';
import FAQ from './components/FAQ';
import Footer from './components/Footer';

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger);

// Create a context for responsive values
const ResponsiveContext = React.createContext();

function App() {
  const responsive = useResponsive();

  useEffect(() => {
    // Initial page load animation
    const loadTl = gsap.timeline();
    
    loadTl.from('body', {
      opacity: 0,
      duration: 0.8,
      ease: 'power2.inOut'
    });

    // Add class to body once JS is loaded
    document.body.classList.add('js-loaded');

    // Cleanup function
    return () => {
      loadTl.kill();
      document.body.classList.remove('js-loaded');
    };
  }, []);

  // Add/remove no-scroll class to body when mobile menu is open
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        document.body.classList.remove('no-scroll');
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <ResponsiveContext.Provider value={responsive}>
      <div className="min-h-screen flex flex-col">
        <Header responsive={responsive} />
        <main className="flex-grow">
          <Hero />
          <Products />
          <FAQ />
        </main>
        <Footer />
      </div>
    </ResponsiveContext.Provider>
  );
}

export { ResponsiveContext };
export default App;
