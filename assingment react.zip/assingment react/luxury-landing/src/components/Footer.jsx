import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const Footer = () => {
  const footerRef = useRef(null);
  const currentYear = new Date().getFullYear();

  // Footer links data
  const footerLinks = [
    {
      title: 'Shop',
      links: [
        { name: 'New Arrivals', url: '#' },
        { name: 'Best Sellers', url: '#' },
        { name: 'Sale', url: '#' },
        { name: 'Gift Cards', url: '#' },
      ],
    },
    {
      title: 'About',
      links: [
        { name: 'Our Story', url: '#' },
        { name: 'Sustainability', url: '#' },
        { name: 'Careers', url: '#' },
        { name: 'Press', url: '#' },
      ],
    },
    {
      title: 'Customer Service',
      links: [
        { name: 'Contact Us', url: '#' },
        { name: 'FAQs', url: '#faq' },
        { name: 'Shipping & Returns', url: '#' },
        { name: 'Size Guide', url: '#' },
      ],
    },
  ];

  // Social media links
  const socialLinks = [
    { name: 'Facebook', icon: 'facebook', url: '#' },
    { name: 'Instagram', icon: 'instagram', url: '#' },
    { name: 'Twitter', icon: 'twitter', url: '#' },
    { name: 'Pinterest', icon: 'pinterest', url: '#' },
  ];

  // Animation on scroll
  useEffect(() => {
    // Animate footer on scroll into view
    gsap.from(footerRef.current, {
      scrollTrigger: {
        trigger: footerRef.current,
        start: 'top 90%',
        toggleActions: 'play none none none',
      },
      y: 30,
      opacity: 0,
      duration: 1,
      ease: 'power2.out',
    });
  }, []);

  // Get social media icon SVG
  const getSocialIcon = (icon) => {
    switch (icon) {
      case 'facebook':
        return (
          <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z" />
        );
      case 'instagram':
        return (
          <>
            <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
            <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z" />
            <line x1="17.5" y1="6.5" x2="17.5" y2="6.5" />
          </>
        );
      case 'twitter':
        return (
          <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z" />
        );
      case 'pinterest':
        return (
          <path d="M12 2C6.5 2 2 6.5 2 12c0 4.1 2.6 7.6 6.2 9 0-.1 0-.2 0-.3 0-.8 0-2.8.5-4 .3-1.1 1.8-7.3 1.8-7.3s-.4-.8-.4-2c0-1.9 1.1-3.3 2.5-3.3 1.2 0 1.8.9 1.8 2 0 1.2-.8 3-1.2 4.6-.3 1.4.7 2.5 2 2.5 2.4 0 4.1-2.8 4.1-6.1 0-2.5-1.8-4.3-4.9-4.3-3.5 0-5.6 2.6-5.6 5.5 0 1 .3 1.7.8 2.3.1.1.1.2.1.3 0 .2-.1.6-.1.7-.1.3-.3.4-.5.3-1.4-.6-2.1-2.1-2.1-3.8 0-2.8 2.4-6.2 7.1-6.2 3.7 0 6.6 2.7 6.6 6.3 0 3.7-2.3 6.6-5.5 6.6-1.1 0-2.1-.6-2.4-1.3l-.7 2.7c-.2.8-.8 1.8-1.2 2.4.9.3 1.9.5 2.9.5 5.5 0 10-4.5 10-10S17.5 2 12 2z" />
        );
      default:
        return null;
    }
  };

  return (
    <footer 
      ref={footerRef}
      className="bg-primary text-white pt-16 pb-8"
    >
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand Info */}
          <div className="lg:col-span-1">
            <h3 className="text-2xl font-serif font-bold mb-4">Luxe</h3>
            <p className="text-gray-300 mb-6">
              Elevating your lifestyle with timeless luxury and impeccable craftsmanship.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-white transition-colors duration-300"
                  aria-label={social.name}
                >
                  <svg 
                    className="w-5 h-5" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    {getSocialIcon(social.icon)}
                  </svg>
                </a>
              ))}
            </div>
          </div>

          {/* Footer Links */}
          {footerLinks.map((column) => (
            <div key={column.title}>
              <h4 className="text-lg font-semibold mb-4">{column.title}</h4>
              <ul className="space-y-3">
                {column.links.map((link) => (
                  <li key={link.name}>
                    <a 
                      href={link.url} 
                      className="text-gray-300 hover:text-white transition-colors duration-300"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Newsletter */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Newsletter</h4>
            <p className="text-gray-300 mb-4">
              Subscribe to receive updates, access to exclusive deals, and more.
            </p>
            <form className="flex">
              <input
                type="email"
                placeholder="Your email"
                className="px-4 py-2 w-full rounded-l-md text-gray-900 focus:outline-none"
                aria-label="Email address"
              />
              <button 
                type="submit"
                className="bg-accent hover:bg-accent-dark text-white px-4 py-2 rounded-r-md transition-colors duration-300"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-700 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            &copy; {currentYear} Luxe. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <a 
              href="#" 
              className="text-gray-400 hover:text-white text-sm transition-colors duration-300"
            >
              Privacy Policy
            </a>
            <a 
              href="#" 
              className="text-gray-400 hover:text-white text-sm transition-colors duration-300"
            >
              Terms of Service
            </a>
            <a 
              href="#" 
              className="text-gray-400 hover:text-white text-sm transition-colors duration-300"
            >
              Cookies
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
