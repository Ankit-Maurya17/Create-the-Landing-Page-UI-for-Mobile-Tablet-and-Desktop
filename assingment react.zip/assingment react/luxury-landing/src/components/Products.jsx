import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

// Register ScrollTrigger plugin
gsap.registerPlugin(ScrollTrigger);

// Sample product data
const products = [
  {
    id: 1,
    name: 'Luxury Watch',
    price: '$1,299',
    description: 'Elegant timepiece with premium materials and precision engineering.',
    image: 'watch',
  },
  {
    id: 2,
    name: 'Leather Wallet',
    price: '$249',
    description: 'Handcrafted from the finest full-grain leather for lasting quality.',
    image: 'wallet',
  },
  {
    id: 3,
    name: 'Sunglasses',
    price: '$399',
    description: 'Luxury eyewear with UV protection and polarized lenses.',
    image: 'sunglasses',
  },
  {
    id: 4,
    name: 'Perfume',
    price: '$189',
    description: 'Exclusive fragrance with long-lasting scent and elegant packaging.',
    image: 'perfume',
  },
];

const Products = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const sectionRef = useRef(null);
  const productRefs = useRef([]);
  const isMobile = window.innerWidth < 768; // Simple mobile detection

  // Add product ref to the refs array
  const addToRefs = (el) => {
    if (el && !productRefs.current.includes(el)) {
      productRefs.current.push(el);
    }
  };

  // Handle slide change
  const goToSlide = (index) => {
    if (index < 0) index = products.length - 1;
    if (index >= products.length) index = 0;
    setCurrentSlide(index);
    
    // Animate the slide change
    if (isMobile) {
      gsap.to(productRefs.current, {
        x: `-${index * 100}%`,
        duration: 0.6,
        ease: 'power2.inOut',
      });
    }
  };

  // Auto-advance slides on mobile with pause on hover
  useEffect(() => {
    if (isMobile) {
      let interval;
      let slider = document.querySelector('.product-slider');
      
      const startAutoSlide = () => {
        interval = setInterval(() => {
          goToSlide((currentSlide + 1) % products.length);
        }, 5000);
      };
      
      const stopAutoSlide = () => {
        clearInterval(interval);
      };
      
      // Start auto-slide
      startAutoSlide();
      
      // Pause on hover
      if (slider) {
        slider.addEventListener('mouseenter', stopAutoSlide);
        slider.addEventListener('mouseleave', startAutoSlide);
        slider.addEventListener('touchstart', stopAutoSlide);
        slider.addEventListener('touchend', startAutoSlide);
      }
      
      // Cleanup
      return () => {
        clearInterval(interval);
        if (slider) {
          slider.removeEventListener('mouseenter', stopAutoSlide);
          slider.removeEventListener('mouseleave', startAutoSlide);
          slider.removeEventListener('touchstart', stopAutoSlide);
          slider.removeEventListener('touchend', startAutoSlide);
        }
      };
    }
  }, [currentSlide, isMobile]);

  // Animation on scroll
  useEffect(() => {
    // Animate section on scroll into view
    gsap.from(sectionRef.current, {
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
      y: 50,
      opacity: 0,
      duration: 1,
      ease: 'power2.out',
    });

    // Animate each product card
    gsap.utils.toArray('.product-card').forEach((card, i) => {
      gsap.from(card, {
        scrollTrigger: {
          trigger: card,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        y: 30,
        opacity: 0,
        duration: 0.6,
        delay: i * 0.1,
        ease: 'power2.out',
      });
    });
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="py-20 bg-gray-50 overflow-hidden"
      id="products"
    >
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-primary mb-4">
            Our Collection
          </h2>
          <div className="w-20 h-1 bg-accent mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Discover our exclusive range of luxury products crafted with precision and attention to detail.
          </p>
        </div>

        {/* Mobile Slider */}
        <div className="md:hidden relative overflow-hidden product-slider">
          <div 
            className="flex transition-transform duration-500 ease-out will-change-transform"
            style={{ transform: `translateX(-${currentSlide * 100}%)` }}
          >
            {products.map((product, index) => (
              <div 
                key={product.id}
                ref={addToRefs}
                className="w-full flex-shrink-0 px-4"
              >
                <div className="bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
                  <div className="relative h-64 bg-gray-200 overflow-hidden">
                    <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                      <span>{product.name} Image</span>
                    </div>
                    {/* Quick view overlay */}
                    <div className="absolute inset-0 bg-black/50 opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <button className="bg-white text-accent px-6 py-2 rounded-full font-medium transform translate-y-4 opacity-0 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
                        Quick View
                      </button>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">{product.name}</h3>
                    <p className="text-gray-600 mb-4 line-clamp-2 min-h-[3rem]">{product.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-accent font-bold text-lg">{product.price}</span>
                      <button 
                        className="bg-accent text-white px-4 py-2 rounded-full hover:bg-accent-dark transition-colors relative overflow-hidden group"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Add to cart logic here
                          const button = e.currentTarget;
                          gsap.fromTo(button,
                            { scale: 1 },
                            { 
                              scale: 1.1, 
                              duration: 0.2, 
                              yoyo: true, 
                              repeat: 1,
                              onComplete: () => {
                                // Show added to cart notification
                                const notification = document.createElement('div');
                                notification.className = 'fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg z-50';
                                notification.textContent = `${product.name} added to cart!`;
                                document.body.appendChild(notification);
                                
                                gsap.fromTo(notification,
                                  { y: 100, opacity: 0 },
                                  { 
                                    y: 0, 
                                    opacity: 1, 
                                    duration: 0.3,
                                    onComplete: () => {
                                      setTimeout(() => {
                                        gsap.to(notification, {
                                          y: 100,
                                          opacity: 0,
                                          duration: 0.3,
                                          onComplete: () => {
                                            document.body.removeChild(notification);
                                          }
                                        });
                                      }, 2000);
                                    }
                                  }
                                );
                              }
                            }
                          );
                        }}
                      >
                        <span className="relative z-10">Add to Cart</span>
                        <span className="absolute inset-0 bg-accent-dark rounded-full transform scale-0 group-hover:scale-100 transition-transform duration-300"></span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Mobile Navigation Arrows */}
          <button 
            onClick={() => goToSlide(currentSlide - 1)}
            className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full p-2 shadow-lg z-10"
            aria-label="Previous product"
          >
            <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <button 
            onClick={() => goToSlide(currentSlide + 1)}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full p-2 shadow-lg z-10"
            aria-label="Next product"
          >
            <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
          
          {/* Mobile Dots */}
          <div className="flex justify-center mt-6 space-x-2">
            {products.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full ${currentSlide === index ? 'bg-accent' : 'bg-gray-300'}`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Desktop Grid */}
        <div className="hidden md:grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product, index) => (
            <div 
              key={product.id}
              className="product-card group"
              onMouseEnter={(e) => {
                // Animate on hover
                gsap.to(e.currentTarget, {
                  y: -5,
                  boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
                  duration: 0.3,
                  ease: 'power2.out'
                });
              }}
              onMouseLeave={(e) => {
                // Reset on mouse leave
                gsap.to(e.currentTarget, {
                  y: 0,
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
                  duration: 0.3,
                  ease: 'power2.out'
                });
              }}
            >
              <div className="bg-white rounded-xl shadow-lg overflow-hidden h-full flex flex-col">
                <div className="relative h-64 bg-gray-200 overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                    <span>{product.name} Image</span>
                  </div>
                  {/* Quick view overlay */}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <button className="bg-white text-accent px-6 py-2 rounded-full font-medium transform translate-y-4 opacity-0 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
                      Quick View
                    </button>
                  </div>
                </div>
                <div className="p-6 flex-grow flex flex-col">
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">{product.name}</h3>
                  <p className="text-gray-600 mb-4 flex-grow">{product.description}</p>
                  <div className="flex justify-between items-center mt-auto">
                    <span className="text-accent font-bold text-lg">{product.price}</span>
                    <button 
                      className="relative overflow-hidden bg-accent text-white px-4 py-2 rounded-full hover:bg-accent-dark transition-colors group"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Add to cart logic here
                        const button = e.currentTarget;
                        gsap.to(button, {
                          scale: 1.1,
                          duration: 0.1,
                          yoyo: true,
                          repeat: 1,
                          onComplete: () => {
                            // Show added to cart notification
                            const notification = document.createElement('div');
                            notification.className = 'fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg z-50';
                            notification.textContent = `${product.name} added to cart!`;
                            document.body.appendChild(notification);
                            
                            gsap.fromTo(notification,
                              { y: 100, opacity: 0 },
                              { 
                                y: 0, 
                                opacity: 1, 
                                duration: 0.3,
                                onComplete: () => {
                                  setTimeout(() => {
                                    gsap.to(notification, {
                                      y: 100,
                                      opacity: 0,
                                      duration: 0.3,
                                      onComplete: () => {
                                        document.body.removeChild(notification);
                                      }
                                    });
                                  }, 2000);
                                }
                              }
                            );
                          }
                        });
                      }}
                    >
                      <span className="relative z-10">Add to Cart</span>
                      <span className="absolute inset-0 bg-accent-dark rounded-full transform scale-0 group-hover:scale-100 transition-transform duration-300"></span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="border-2 border-primary text-primary px-8 py-3 rounded-full hover:bg-primary hover:text-white transition-colors duration-300 font-medium">
            View All Products
          </button>
        </div>
      </div>
    </section>
  );
};

export default Products;
