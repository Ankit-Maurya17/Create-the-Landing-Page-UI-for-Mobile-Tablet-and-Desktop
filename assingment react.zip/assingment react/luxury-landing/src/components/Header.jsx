import { useState, useEffect, useRef, useContext } from 'react';
import { gsap } from 'gsap';
import { ResponsiveContext } from '../App';

const Header = () => {
  const responsive = useContext(ResponsiveContext);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const headerRef = useRef(null);
  const navRef = useRef(null);
  const mobileMenuRef = useRef(null);
  const menuButtonRef = useRef(null);
  const animation = useRef(null);

  // Toggle mobile menu with animation
  const toggleMenu = () => {
    if (!isMenuOpen) {
      // Opening animation
      document.body.classList.add('no-scroll');
      
      if (mobileMenuRef.current) {
        // Reset styles before animation
        gsap.set(mobileMenuRef.current, { 
          display: 'flex',
          height: 0,
          opacity: 0,
          y: -20
        });
        
        // Animate menu in
        animation.current = gsap.to(mobileMenuRef.current, {
          height: 'auto',
          opacity: 1,
          y: 0,
          duration: 0.4,
          ease: 'power2.inOut',
          onComplete: () => {
            if (mobileMenuRef.current) {
              gsap.set(mobileMenuRef.current, { height: 'auto' });
            }
          }
        });
      }
    } else {
      // Closing animation
      if (mobileMenuRef.current) {
        animation.current = gsap.to(mobileMenuRef.current, {
          height: 0,
          opacity: 0,
          y: -20,
          duration: 0.3,
          ease: 'power2.inOut',
          onComplete: () => {
            if (mobileMenuRef.current) {
              gsap.set(mobileMenuRef.current, { display: 'none' });
            }
            document.body.classList.remove('no-scroll');
          }
        });
      } else {
        document.body.classList.remove('no-scroll');
      }
    }
    
    // Toggle menu state after starting animation
    setIsMenuOpen(!isMenuOpen);
  };

  useEffect(() => {
    // Animate header on mount
    gsap.from(headerRef.current, {
      y: -100,
      opacity: 0,
      duration: 1,
      ease: 'power3.out',
      delay: 0.5
    });
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header 
      ref={headerRef}
      className={`fixed w-full z-50 transition-all duration-300 py-3 md:py-4 ${
        isScrolled 
          ? 'bg-white/95 shadow-md backdrop-blur-sm py-2' 
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <a 
            href="#" 
            className="text-2xl font-bold text-accent hover:opacity-90 transition-opacity"
            onClick={(e) => {
              if (isMenuOpen) {
                e.preventDefault();
                toggleMenu();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
          >
            Luxury
          </a>
          
          {/* Desktop Navigation */}
          <nav ref={navRef} className="hidden md:block">
            <ul className="flex space-x-2 lg:space-x-6">
              {[
                { name: 'Home', href: '#' },
                { name: 'Products', href: '#products' },
                { name: 'About', href: '#about' },
                { name: 'FAQ', href: '#faq' },
                { name: 'Contact', href: '#contact' }
              ].map((item) => (
                <li key={item.name}>
                  <a 
                    href={item.href}
                    className={`px-3 py-2 text-sm lg:text-base font-medium transition-colors rounded-md ${
                      isScrolled 
                        ? 'text-gray-700 hover:text-accent' 
                        : 'text-white hover:text-accent/90'
                    }`}
                  >
                    {item.name}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            ref={menuButtonRef}
            className={`md:hidden p-2 rounded-full focus:outline-none focus:ring-2 focus:ring-accent focus:ring-opacity-50 transition-colors ${
              isScrolled || isMenuOpen 
                ? 'text-gray-700 hover:bg-gray-100' 
                : 'text-white hover:bg-white/10'
            }`}
            onClick={toggleMenu}
            aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={isMenuOpen}
            aria-controls="mobile-menu"
          >
            {isMenuOpen ? (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
              </svg>
            )}
          </button>
        </div>
        
        {/* Mobile Menu */}
        <div 
          ref={mobileMenuRef}
          id="mobile-menu"
          className={`md:hidden mt-4 transition-all duration-300 ease-in-out overflow-hidden ${
            isMenuOpen 
              ? 'opacity-100 max-h-96' 
              : 'opacity-0 max-h-0'
          }`}
          style={{
            display: isMenuOpen ? 'block' : 'none',
            height: isMenuOpen ? 'auto' : 0
          }}
        >
          <div className="bg-white rounded-xl shadow-xl p-4 space-y-1">
            {[
              { name: 'Home', href: '#', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
              { name: 'Products', href: '#products', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
              { name: 'About', href: '#about', icon: 'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
              { name: 'FAQ', href: '#faq', icon: 'M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
              { name: 'Contact', href: '#contact', icon: 'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z' }
            ].map((item, index) => (
              <a
                key={item.name}
                href={item.href}
                className="flex items-center px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors group"
                onClick={() => {
                  toggleMenu();
                  // Smooth scroll to section
                  if (item.href.startsWith('#')) {
                    const target = document.querySelector(item.href);
                    if (target) {
                      setTimeout(() => {
                        target.scrollIntoView({ behavior: 'smooth' });
                      }, 300);
                    }
                  }
                }}
              >
                <svg 
                  className="w-5 h-5 mr-3 text-gray-400 group-hover:text-accent transition-colors" 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
                </svg>
                <span className="font-medium">{item.name}</span>
              </a>
            ))}
            
            {/* Mobile menu call to action */}
            <div className="pt-2 mt-2 border-t border-gray-100">
              <a 
                href="#contact" 
                className="block w-full text-center bg-accent text-white py-2.5 px-4 rounded-lg font-medium hover:bg-accent-dark transition-colors"
                onClick={toggleMenu}
              >
                Get in Touch
              </a>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
