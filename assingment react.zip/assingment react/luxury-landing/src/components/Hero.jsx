import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

// Split text into spans for word-by-word animation
const AnimatedText = ({ text, className = '' }) => {
  return text.split(' ').map((word, i) => (
    <span key={i} className={`inline-block overflow-hidden ${className}`}>
      <span className="inline-block will-change-transform">
        {word}
      </span>
      {i < text.split(' ').length - 1 ? ' ' : ''}
    </span>
  ));
};

const Hero = () => {
  const heroRef = useRef(null);
  const titleRef = useRef(null);
  const subtitleRef = useRef(null);
  const ctaRef = useRef(null);
  const imageRef = useRef(null);

  useEffect(() => {
    const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

    // Animate title words
    tl.from(titleRef.current.querySelectorAll('.title-word > span'), {
      y: '100%',
      opacity: 0.3,
      rotateX: -40,
      duration: 1,
      stagger: 0.05,
      ease: 'back.out(1.2)',
    });

    // Animate subtitle words
    tl.from(subtitleRef.current.querySelectorAll('.subtitle-word > span'), {
      y: '100%',
      opacity: 0,
      duration: 0.5,
      stagger: 0.02,
      ease: 'power2.out',
    }, '-=0.8');

    // Animate CTA buttons
    tl.from(ctaRef.current.children, {
      y: 20,
      opacity: 0,
      duration: 0.8,
      stagger: 0.1,
      ease: 'back.out(1.7)'
    }, '-=0.6');

    // Animate image
    tl.from(imageRef.current, {
      scale: 0.9,
      opacity: 0,
      filter: 'blur(10px)',
      duration: 1.5,
      ease: 'back.out(1.4)'
    }, '-=0.8');

    return () => tl.kill();
  }, []);

  const title = "Elegance Redefined";
  const subtitle = "Discover our exclusive collection of luxury products designed to elevate your lifestyle.";

  return (
    <section 
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center pt-20 md:pt-0 overflow-hidden"
    >
      <div className="absolute inset-0 bg-gray-100 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-white/90 via-white/70 to-white/90 z-10"></div>
      </div>
      
      <div className="container mx-auto px-6 z-20">
        <div className="flex flex-col md:flex-row items-center">
          {/* Text Content */}
          <div className="md:w-1/2 text-center md:text-left mb-12 md:mb-0">
            <div className="overflow-hidden">
              <h1 
                ref={titleRef}
                className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-primary mb-6 leading-tight"
              >
                <AnimatedText text={title} className="title-word" />
              </h1>
            </div>
            
            <div className="overflow-hidden">
              <p 
                ref={subtitleRef}
                className="text-lg md:text-xl text-gray-600 mb-8 max-w-lg mx-auto md:mx-0"
              >
                <AnimatedText text={subtitle} className="subtitle-word" />
              </p>
            </div>
            
            <div ref={ctaRef} className="space-x-4">
              <button className="bg-accent text-white px-8 py-3 rounded-full hover:bg-accent-dark transition-colors duration-300 font-medium">
                Shop Collection
              </button>
              <button className="border-2 border-primary text-primary px-8 py-3 rounded-full hover:bg-primary hover:text-white transition-colors duration-300 font-medium">
                Learn More
              </button>
            </div>
          </div>
          
          {/* Image */}
          <div className="md:w-1/2 flex justify-center">
            <div 
              ref={imageRef}
              className="relative w-full max-w-md h-96 md:h-[500px] bg-gray-200 rounded-2xl overflow-hidden shadow-xl transform transition-transform duration-500 hover:scale-105"
            >
              {/* Placeholder for product image */}
              <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                <span>Product Image</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative Elements */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  );
};

export default Hero;
