import { useState, useRef, useEffect } from 'react';
import { gsap } from 'gsap';

const FAQ = () => {
  const [activeIndex, setActiveIndex] = useState(null);
  const sectionRef = useRef(null);
  const itemRefs = useRef([]);

  // FAQ data
  const faqItems = [
    {
      question: 'What is your return policy?',
      answer: 'We offer a 30-day return policy for all our products. If you are not completely satisfied with your purchase, you can return it within 30 days for a full refund or exchange. The item must be in its original condition with all tags attached.'
    },
    {
      question: 'How long does shipping take?',
      answer: 'Standard shipping typically takes 3-5 business days within the continental US. For international orders, please allow 7-14 business days. Expedited shipping options are available at checkout for faster delivery.'
    },
    {
      question: 'Do you ship internationally?',
      answer: 'Yes, we ship to most countries worldwide. International shipping rates and delivery times vary by destination. Additional customs fees, taxes, or duties may apply upon delivery and are the responsibility of the recipient.'
    },
    {
      question: 'How can I track my order?',
      answer: 'Once your order has shipped, you will receive a confirmation email with a tracking number and a link to track your package. You can also log in to your account to view the status of your order and track its progress.'
    },
    {
      question: 'What payment methods do you accept?',
      answer: 'We accept all major credit cards (Visa, Mastercard, American Express, Discover), PayPal, and Apple Pay. All transactions are secure and encrypted for your protection.'
    }
  ];

  // Toggle FAQ item with animation
  const toggleItem = (index) => {
    const wasActive = activeIndex === index;
    const answer = document.getElementById(`answer-${index}`);
    
    // Close all items if one is open and a different one is clicked
    if (activeIndex !== null && activeIndex !== index) {
      const prevAnswer = document.getElementById(`answer-${activeIndex}`);
      if (prevAnswer) {
        gsap.to(prevAnswer, {
          height: 0,
          opacity: 0,
          duration: 0.3,
          ease: 'power2.inOut',
          onComplete: () => {
            prevAnswer.style.display = 'none';
          }
        });
      }
    }
    
    // Toggle current item
    if (wasActive) {
      // Closing animation
      gsap.to(answer, {
        height: 0,
        opacity: 0,
        duration: 0.3,
        ease: 'power2.inOut',
        onComplete: () => {
          answer.style.display = 'none';
          setActiveIndex(null);
        }
      });
    } else {
      // Opening animation
      setActiveIndex(index);
      answer.style.display = 'block';
      
      // Get the height of the content
      const height = answer.scrollHeight;
      
      // Set initial state
      gsap.set(answer, { height: 0, opacity: 0 });
      
      // Animate to full height
      gsap.to(answer, {
        height: height,
        opacity: 1,
        duration: 0.4,
        ease: 'power2.inOut',
        onComplete: () => {
          // Remove fixed height to allow for responsive resizing
          gsap.set(answer, { height: 'auto' });
        }
      });
    }
  };

  // Animate FAQ items on scroll
  useEffect(() => {
    // Animate section on scroll into view
    gsap.from(sectionRef.current, {
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
      y: 50,
      opacity: 0,
      duration: 1,
      ease: 'power2.out',
    });

    // Animate each FAQ item
    itemRefs.current.forEach((item, index) => {
      gsap.from(item, {
        scrollTrigger: {
          trigger: item,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        y: 30,
        opacity: 0,
        duration: 0.6,
        delay: index * 0.1,
        ease: 'power2.out',
      });
    });
  }, []);

  // Handle window resize to adjust heights
  useEffect(() => {
    const handleResize = () => {
      if (activeIndex !== null) {
        const answer = document.getElementById(`answer-${activeIndex}`);
        if (answer) {
          // Temporarily set height to auto to get the correct height
          gsap.set(answer, { height: 'auto' });
          const height = answer.scrollHeight;
          gsap.set(answer, { height: height });
        }
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [activeIndex]);

  return (
    <section 
      ref={sectionRef}
      className="py-20 bg-white"
      id="faq"
    >
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-primary mb-4">
            Frequently Asked Questions
          </h2>
          <div className="w-20 h-1 bg-accent mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Find answers to common questions about our products, shipping, returns, and more.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          {faqItems.map((item, index) => (
            <div 
              key={index}
              ref={el => itemRefs.current[index] = el}
              className="mb-4 border-b border-gray-200 last:border-0"
            >
              <button
                className={`w-full text-left py-5 px-4 rounded-lg transition-all duration-200 flex justify-between items-center ${
                  activeIndex === index 
                    ? 'bg-gray-50 text-accent' 
                    : 'hover:bg-gray-50 hover:text-gray-900'
                }`}
                onClick={() => toggleItem(index)}
                aria-expanded={activeIndex === index}
                aria-controls={`answer-${index}`}
              >
                <span className="text-lg font-medium text-gray-800">
                  {item.question}
                </span>
                <svg 
                  className={`w-5 h-5 text-gray-500 transition-transform duration-200 ${activeIndex === index ? 'transform rotate-180' : ''}`}
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M19 9l-7 7-7-7" 
                  />
                </svg>
              </button>
              <div 
                id={`answer-${index}`}
                className="faq-answer overflow-hidden"
                style={{ 
                  display: activeIndex === index ? 'block' : 'none',
                  height: 0,
                  opacity: 0
                }}
                aria-hidden={activeIndex !== index}
              >
                <div className="px-4 pb-6 pt-2 text-gray-600">
                  {item.answer}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600 mb-6">
            Still have questions? We're here to help!
          </p>
          <button className="bg-accent text-white px-8 py-3 rounded-full hover:bg-accent-dark transition-colors duration-300 font-medium">
            Contact Us
          </button>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
